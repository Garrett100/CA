public class DebugOne3
{
   public static void main(String[] args)
   {
      System.out.println("Over the river");
      System.out.println("and through the woods");
      System.out.println("to Grandmother's house we go");
   }
}
