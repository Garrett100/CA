public class DebugTwo1
{
   public static void main(String[] args)
   {
      int oneInt = 315;
      double oneDouble = 12.4;

      System.out.println("The int is");
      System.out.print(oneInt);
      System.out.println("The double is");
      System.out.print(oneDouble);

   }
}
