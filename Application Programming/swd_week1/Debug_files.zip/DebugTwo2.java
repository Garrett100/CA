public class DebugTwo2
//  This application performs arithmetic with two integers
{
  public static void main(String args[])
  {
    int a, b, c, d, e;
    a = 7;
    b = 4;
    c = a+b;
    d = a-b;
    e = a*b;


    System.out.println("The sum is " +c);
    System.out.println("The difference is " +d);
    System.out.println("The product is " +e);
}
}