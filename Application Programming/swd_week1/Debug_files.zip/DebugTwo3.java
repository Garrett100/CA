public class DebugTwo3
// Demonstrates remainder and output
{
  public static void main(String args[])
  {
      double a = 99, b = 8;
      long c = 7777777777777L;

      double d;
      double e;
      d=a/b;
      e=a%b;

      System.out.println("Divide " + d);
      System.out.println("remainder is " +e);
      System.out.print("c is a very large number:");
      System.out.println(c);
   }

}
