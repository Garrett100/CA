/** Multiply two numbers
Author Garrett
01/10/14**/

public class Multiplier2{

    public static void main(String args[]) {

	int firstNumber;
	int secondNumber;
	int result = 0;

	firstNumber = 37;
	secondNumber = 194;


//multiply the two numbers//

	result = firstNumber * secondNumber;

	//output the result//
	System.out.println("firstNumber" + firstNumber + "secondNumber" + secondNumber);
	System.out.println(" = " + result);
	System.out.println("result");

   }

}