import java.util.Scanner;


public class ChangeCalculator{

    public static void main(String args[]) {

					double euro50 = 50;
					double euro20 = 20;
					double euro10 = 10;
					double euro5 = 5;
					double euro2 = 2;
					double euro1 = 1;
					double number;

Scanner sc = new Scanner(System.in);




    System.out.println("Please enter price:");
    number = sc.nextDouble();

       	System.out.println(Math.floor(number));



   }

}