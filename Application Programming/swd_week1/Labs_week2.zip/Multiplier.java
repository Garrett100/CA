/** Multiply two numbers
Author Garrett
01/10/14**/

public class Multiplier{

    public static void main(String args[]) {

	int firstNumber = 37;
	int secondNumber = 194;

    System.out.println("firstNumber is " + firstNumber);
    System.out.println("secondNumber is " + secondNumber);

	int thirdNumber = firstNumber*secondNumber;

    System.out.println("firstNumber * secondNumber is " + thirdNumber);

   }

}