public class Numbers1{
	public static void main(String[] args){

			double da = 2.3;
			double db = 12.19;
			double dc = db/da;



		System.out.println(" db: " + db + " / da: " + da + " = dc: " + dc);
		System.out.println();





			db = 35.7;

				System.out.println("db: " + db);
				dc = Math.floor(db);
				System.out.println("floor: db: " + dc);
				dc = Math.round(db);
				System.out.println("round: db: " + dc);
				dc = Math.ceil(db);
				System.out.println("ceil: db: " + dc);
				System.out.println();

	}
	}