public class Square{

    public static void main(String args[]) {

int length = 7;
int area = length * length;

System.out.println("lenght * length = " + area);
System.out.println();
   }

}